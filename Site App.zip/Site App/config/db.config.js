module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "password",
    DB: "devdatabase"
  };